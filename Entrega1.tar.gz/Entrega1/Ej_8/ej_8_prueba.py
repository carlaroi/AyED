from ej_8 import Complejo

def obtener_polinomio(): # Creamos una función que pida por consola la parte real e imaginaria de un complejo
    real = int(input("Introduce la parte real del número: "))
    imag = int(input("Introduce la parte imaginaria del número: "))
    return Complejo(real, imag)

def mostrar_menu(): # Función que imprime un menú por pantalla con todas las operaciones posibles con complejos
    print(f"\n¿Qué operación deseas realizar?: ")
    print("1. Sumar dos complejos")
    print("2. Restar dos complejos")
    print("3. Multiplicar dos complejos")
    print("4. Dividir dos complejos")
    print("5. Módulo de un complejo")
    print("6. Conjugado del complejo")
    print("7. Argumento del complejo")
    print("8. Salir")

def main(): # Función principal del programa, que se ejecutará mientras la opción 'salir' NO sea escogida
    while True:
        mostrar_menu()
        opcion = input("Seleccione una opción: ")

        if opcion == "1": # Opción SUMA
            c1 = obtener_polinomio()
            c2 = obtener_polinomio()
            resultado = c1 + c2
            print("Resultado:", resultado)

        elif opcion == "2": # Opción RESTA
            c1 = obtener_polinomio()
            c2 = obtener_polinomio()
            resultado = c1 - c2
            print("Resultado:", resultado)

        elif opcion == "3": # Opción MULTIPLICACIÓN
            c1 = obtener_polinomio()
            c2 = obtener_polinomio()
            resultado = c1 * c2
            print("Resultado:", resultado)

        elif opcion == "4": # Opción DIVISIÓN COMPLEJA
            c1 = obtener_polinomio()
            c2 = obtener_polinomio()
            resultado = c1 / c2
            print("Resultado: ", resultado)
            
        elif opcion == "5": # Opción MÓDULO
            c1 = obtener_polinomio()
            resultado = c1.modulo()
            print("Resultado: ", resultado)

        elif opcion == "6": # Opción CONJUGADO
            c1 = obtener_polinomio()
            resultado = c1.conjugado()
            print("Resultado: ", resultado)

        elif opcion == "7": # Opcion ARGUMENTO
            c1 = obtener_polinomio()
            resultado = c1.argumento()
            print("Resultado: ", resultado)

        elif opcion == "8": # Opción SALIR
            print("Chao pescao")
            break

        else: # El programa pedirá un valor válido del menú siempre que este no sea correcto
            print("Opción inválida. Selecciona una válida.")

if __name__ == "__main__": # El programa se ejecutará siempre que lea la función main y esta sea verdad
    main()

