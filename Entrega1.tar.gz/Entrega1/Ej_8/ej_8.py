# Implementar con todos sus componentes la clase Complejo, de manera que se puedan ejecutar todas las
# operaciones sobre complejos

import math # Importamos la librería math para poder utilizar la función complex y así facilitar la resolución del programa

class Complejo: # Definimos la clase
    def __init__(self, real, imag): # La clase complejo tiene los atributos 'real' e 'imag' 
        self.real = real
        self.imag = imag

    def __str__(self): # Formato de salida de los complejos por pantalla
        if self.imag >= 0:
            return f"{self.real} + {self.imag}i"
        else:
            return f"{self.real} - {-self.imag}i"

    def __add__(self, other): # Definimos el método __add__ y así suma funciona correctamente
        return Complejo(self.real + other.real, self.imag + other.imag)

    def __sub__(self, other): # Definimos el método __sub__ y así la resta funciona correctamente
        return Complejo(self.real - other.real, self.imag - other.imag)

    def __mul__(self, other): # Definimos el método __mul__ y así la multiplicación funciona correctamente
        return Complejo(self.real * other.real - self.imag * other.imag,
                        self.real * other.imag + self.imag * other.real)
    
    def __truediv__(self, other): # Definimos el método __truediv__ y así la división funciona correctamente
        divisor = other.real ** 2 + other.imag ** 2
        real = (self.real * other.real + self.imag * other.imag) / divisor
        imag = (self.imag * other.real - self.real * other.imag) / divisor
        return Complejo(real, imag)
   
    def modulo(self):  # Definimos el método modulo para que funcione correctamente
        return math.sqrt(self.real ** 2 + self.imag ** 2)

    def conjugado(self):  # Definimos el método conjugado para que funcione correctamente
        return Complejo(self.real, -self.imag)

    def argumento(self): # Definimos el método argumento para que funcione correctamente
        return math.atan2(self.imag, self.real)

