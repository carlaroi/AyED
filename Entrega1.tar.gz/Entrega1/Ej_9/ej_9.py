# En un juego de dados, todos los participantes tienen el mismo número de dados (con n caras, de la 1 a la n).
# En cada turno, cada jugador tira todos sus dados, sumando cada dado para obtener una puntuación. Gana el
# jugador con mejor puntuación tras x turnos.

import random # Importamos la clase random para la tirada de dados.
 
 
class Dado:
    # La clase dado representa un dado de seis caras, de 1 a 6.
 
    def __init__(self): 
        self.ultimo_resultado = 0 # Inicialización el último resultado en 0
 
    def tirada(self):
        self.ultimo_resultado = random.randint(1, 6) # Utilización la librería random para generar tantos valores como caras tiene un dado 
        return self.ultimo_resultado
 
    def __str__(self): # Generación del formato a imprimir por pantalla del último resultado
        return str(self.ultimo_resultado)
 
 
class Jugador:
    # La clase jugador representa a un jugador que tiene x dados.
 
    def __init__(self, nick, num_dados):
        #Crea un nuevo jugador.
 
        # parámetro nick: El nick del jugador.
        # parámetro num_dados: El num. de dados para la partida.
 
        self.nick = nick
        self.num_dados = num_dados
        self.dados = [] # Creamos una lista vacía que almacenará el numero de dados
        self.ultima_tirada = []
        for i in range(num_dados):
            self.dados += [Dado()]
 
    def tirada(self):
        # Realiza una tirada con todos los dados.
 
        self.ultima_tirada = [] # Creamos una lista vacía que almacenará las últimas tiradas de cada jugador
 
        for dado in self.dados:
            self.ultima_tirada += [dado.tirada()]
 
        return self.ultima_tirada
 
    def __str__(self): # Formato de salida por pantalla del jugador
        toret = self.nick + ": "
 
        for x in self.ultima_tirada:
            toret += str(x) + ' '
 
        return toret.strip()
 
 
class Juego:
    # Representa un juego de 'x' jugadores e 'y' turnos.
    # Permitirá incorporar jugadores.
    # El método juega() lanza los y turnos, guardando los resultados parciales y la puntuación total.
 
    def __init__(self, num_turnos, num_dados):
        # Crea un nuevo juego.
        # param num_turnos: El num. de turnos a jugar.
        # param num_dados: El num. de dados para todos.
 
        self.num_turnos = num_turnos
        self.num_dados = num_dados
        # Generamos listas vacías que almacenarán las variables 'jugadores', 'puntos max', 'puntos parciales' y 'turnos'
        self.jugadores = [] 
        self.puntos_max = []
        self.puntos_parciales = []
        self.turnos = []
 
    def inserta_jugador(self, nick): # Función que incorporará al juego un objeto de la clase 'jugador'
        self.jugadores += [Jugador(nick, self.num_dados)] 
 
    def juega(self):
         # Inicialización de la lista puntos_max con ceros, 
         # su longitud es igual a la cantidad de jugadores
        self.puntos_max = [0] * len(self.jugadores) 
        self.turnos = []

        for _ in range(self.num_turnos):
            self.puntos_parciales = [[]] * len(self.jugadores)
 
            # Bucle que itera sobre los índices y los jugadores en la lista jugadores
            for i, jugador in enumerate(self.jugadores):
               # Llamada al método tirada del jugador actual y almacenamiento de su resultado en la variable pts
                pts = jugador.tirada()
                
                # Suma de los puntos obtenidos en la tirada actual y los acumulados anteriormente por el jugador actual
                self.puntos_max[i] += sum(pts)
                
                # Almacenamiento de la última tirada del jugador actual en la lista puntos_parciales
                self.puntos_parciales[i] = list(jugador.ultima_tirada)
 
    def __str__(self): # Formato de salida por pantalla de la clase juego
        toret = str.format("Juego de {0} turnos y {1} dados.\n\n",
                            self.num_turnos, self.num_dados)
 
        for puntos in self.turnos:
            for i, pts in enumerate(puntos):
                toret += self.jugadores[i].nick + ": " + str(pts)
 
                toret += '\n'
            toret += '\n'
 
        toret += "Puntuaciones finales:\n"
        for i, pts in enumerate(self.puntos_max):
            toret += self.jugadores[i].nick + ": " + str(pts) + '\n'
 
        return toret
 
if __name__ == "__main__": 
    # Inicializa el generador de números aleatorios
    random.seed()
     # Crea un objeto de la clase Juego con un número aleatorio de jugadores y turnos
    juego = Juego(random.randint(2, 6), random.randint(3, 6))
    # Añadimos jugadores al juego
    juego.inserta_jugador("Carla")
    juego.inserta_jugador("Miguel")
    juego.inserta_jugador("PereGil")
    juego.inserta_jugador("MiguelaMagdalena")
    # Inicialización del juego
    juego.juega()
    # Impresión por pantalla del juego
    print(juego)