from ej_7 import Polinomio

def obtener_polinomio(): # Creamos una función que pida por pantalla un polinomio
    valores = input("Ingrese los coeficientes del polinomio separados por espacios: ") # Cada elemento separado por un espacio será un coeficiente del polinomio
    return Polinomio(valores) 

def mostrar_menu(): # Creamos un menú que facilite al usuario la elección de las operaciones
    print("\nMenú:")
    print("1. Sumar dos polinomios")
    print("2. Restar dos polinomios")
    print("3. Multiplicar dos polinomios")
    print("4. Dividir un polinomio por otro")
    print("5. Salir")

def main(): # Programa principal que se ejecutará siempre que la opción 'salir' no sea la escogida
    while True: 
        mostrar_menu() # Se muestra el menú
        opcion = input("Seleccione una opción: ")

        if opcion == "1": # Opción que suma los polinomios
            p1 = obtener_polinomio()
            p2 = obtener_polinomio()
            resultado = p1 + p2
            print("Resultado:", resultado.__str__())

        elif opcion == "2": # Opción que resta los polinomios
            p1 = obtener_polinomio()
            p2 = obtener_polinomio()
            resultado = p1 - p2
            print("Resultado:", resultado.__str__())

        elif opcion == "3": # Opción que multiplica los polinomios
            p1 = obtener_polinomio()
            p2 = obtener_polinomio()
            resultado = p1 * p2
            print("Resultado:", resultado.__str__())

        elif opcion == "4": # Opción que divide los polinomios
            p1 = obtener_polinomio()
            p2 = obtener_polinomio()
            try:
                resultado = p1 / p2
                print("Resultado:", resultado.__str__())
            except ValueError as e:
                print("Error:", e) # Lanza la excepción cuando el denominador es 0

        elif opcion == "5":
            print("Chao pescao")
            break # Fin de la funcion main y del bucle

        else:
            print("Opción inválida. Selecciona una válida.")

if __name__ == "__main__":
    main()