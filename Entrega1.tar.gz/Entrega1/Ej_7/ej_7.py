# Implementar con todos sus componentes la clase Polinomio, de manera que se puedan ejecutar todas las
# operaciones sobre polinomios

from numpy import *
import numpy as np # Importamos la librería numpy, necesaria para realizar operaciones esenciales con polinomios

class Polinomio: # Definimos la clase polinomio, esta clase estará definida por si misma así como por los coeficientes  
        def __init__(self, valores):
            try:
                pol = valores.split() # separamos cada uno de los elementos de la lista del polinomio la longitud de la lista nos indicará su grado implicitamente)
                for i in range (len(pol)): 
                    pol[i] = float(pol[i]) # Transformarmos a float cada uno de los elementos de la lista de valores del polinomio
                self.pol = pol
            except ValueError:
                print("Algo ha salido mal, porfavor, introduce valores válidos") # Si se introduce un valor no válido, se lanza una excepción 
                quit() 


        def __str__(self): # Definimos el formato de salida de los polinomios
            return "[" + " ".join(map(str, self.pol)) + "]"
                
        # Operación SUMA
        def __add__(self, otro):
            return np.polyadd(self.pol, otro.pol)

        #Operación RESTA
        def __sub__(self, otro):
            return np.polysub(self.pol, otro.pol)

        #Operación MULTIPLICACIÓN
        def __mul__(self, otro):
            return np.polymul(self.pol, otro.pol)

        #Operación DIVISIÓN
        def __truediv__(self, otro):
            if np.allclose(otro.pol, 0):
                raise ValueError("NO se puede dividir por 0")
            return np.polydiv(self.pol, otro.pol)


        


